<?php

class Conexao
{


    public function getConexao()
    {


        $host = 'localhost';
        $port = '3306';
        $dbname = 'carros';
        $usuario = 'root';
        $senha = '';

        $conexao = new PDO(
            'mysql:host=' . $host . ';port=' . $port . ';dbname=' . $dbname . '',
            $usuario,
            $senha
        );

        return $conexao;
    }
}
