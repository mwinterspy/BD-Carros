<?php



require 'Carro.php';
$c = new Carro();

$carros = [];

if (isset($_GET['search'])) {
    $search = $_GET['search'];
    $option  = $_GET['option'];
} else {
    $search = '';
}

if ($search != '') {
    if ($option == "1") {
        $carros = $c->listarCodigo($search);
    }else if($option =="2"){
        $carros = $c->listarPlaca($search);
    }else if($option =="3"){
        $carros = $c->listarRenavam($search);
    }
    else if($option =="4"){
        $carros = $c->listarDataCompra($search);
    }
    else if($option =="5"){
        $carros = $c->listarMarca($search);
    }else if ($option == "6"){
    $carros = $c->listarModelo($search);
    }else if($option =="7"){
        $carros = $c->listarTipo($search);
    }else if($option =="8"){
        $carros = $c->listarCor($search);
    }else if($option =="9"){
        $carros = $c->listarAnoModelo($search);
    }else if($option =="10"){
        $carros = $c->listarAnoFabricacao($search);
    }

}else{
    $carros= $c->listar();
}




?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista Veículos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Young+Serif&display=swap" rel="stylesheet">

</head>
<header>
    <div class="container" style="margin-bottom: 150px">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark navbar fixed-top">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php"><i class="fa-solid fa-car-side"></i> Home</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Lista de Carros
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="lista.php">Exibir lista</a></li>
                                <li><a class="dropdown-item" href="cadastrar.php">Cadastrar novo veículo</a></li>
                            </ul>
                        </li>
                    </ul>
                    </form>
                </div>
            </div>

        </nav>
    </div>

</header>

<body id="bodyHome2">
    <div style="display:flex; justify-content: center;">
        <h1 style="font-family: 'Young Serif', serif; color: white; font-weight: 600; border: double 4px rgb(212,175,55); width:337px;">MR. Motorsport</h1>
    </div>

    <div style="margin: 50px">
        <form action="lista.php" method="GET">
            <div class="input-group" style="width: 500px; margin-bottom: 10px;" id="searchbar">
                <input type="text" class="form-control" name="search" id="search" style="background-color: rgba(0,0,0); color: rgb(212,175,55); border:solid rgb(212,175,55) 5px; border-right: solid rgb(212,175,55) 2px;">
                <select style="border: solid 4px rgb(212,175,55); background-color: black; color: rgb(212,175,55); border-right: 0px; width: 120px; text-align:center;" name="option">
                    <option value="0">SELECIONE</option>
                    <option value="1">Código</option>
                    <option value="2">Placa</option>
                    <option value="3">Renavam</option>
                    <option value="4">Data compra</option>
                    <option value="5">Marca</option>
                    <option value="6">Modelo</option>
                    <option value="7">Tipo</option>
                    <option value="8">Cor</option>
                    <option value="9">Ano Modelo</option>
                    <option value="10">Ano Fabricação</option>
                </select>
                <button class="btn btn-outline-secondary" type="submit" id="button-addon1" style="border: solid 4px rgb(212,175,55); background-color: black"><i class="fa-solid fa-magnifying-glass"></i></button>
            </div>
        </form>

        <table class="table table-striped table-bordered">
            <thead class="table-dark">
                <tr>
                    <th scope="col">Código</th>
                    <th scope="col">Placa</th>
                    <th scope="col">Renavam</th>
                    <th scope="col">Data da Compra</th>
                    <th scope="col">Marca</th>
                    <th scope="col">Modelo</th>
                    <th scope="col">Tipo</th>
                    <th scope="col">Cor</th>
                    <th scope="col">Ano Modelo</th>
                    <th scope="col">Ano Fabricação</th>
                    <th scope="col">Ações</th>
                </tr>
            </thead>

            <?php

            foreach ($carros as $carro) {

            ?>
                <tbody>
                    <tr>
                        <td><?php echo $carro->codigo ?></td>
                        <td><?php echo $carro->placa ?></td>
                        <td><?php echo $carro->renavam ?></td>
                        <td><?php echo $carro->formatData() ?></td>
                        <td><?php echo $carro->marca ?></td>
                        <td><?php echo $carro->modelo ?></td>
                        <td><?php echo $carro->tipo ?></td>
                        <td><?php echo $carro->cor ?></td>
                        <td><?php echo $carro->anoModelo ?></td>
                        <td><?php echo $carro->anoFabricacao ?></td>
                        <td style="text-align: center;">
                            <a href="eliminar-registro.php?codigoEliminar= <?php echo $carro->codigo; ?>" style="color:red; text-decoration: none; font-weight: 1000; margin-right: 10px; "><i class="fa-solid fa-trash-can"></i></a>
                            <a href="cadastrar.php?codigo=<?php echo $carro->codigo?>"><i class="fa-solid fa-pen-to-square"></i></a>
                        </td>
                    </tr>
                </tbody>




            <?php
            }
            ?>



</body>


</html>