<?php

require 'Carro.php';

$c = new Carro();

$codigoEliminar = $_GET['codigoEliminar'];

$c->eliminar($codigoEliminar);

header('Location: lista.php');
?>