<?php

require 'Models/carroModel.php';
require 'conexao.php';


class Carro
{

    public $conexao;
    public function __construct()
    {
        $conec = new Conexao();
        $this->conexao = $conec->getConexao();
    }


    private function mapear($q)
    {
        $listadeCarros = [];
        foreach ($q as $dados) {
            $carro = new carroModel();
            $carro->codigo = $dados['codigo'];
            $carro->placa = $dados['placa'];
            $carro->renavam = $dados['renavam'];
            $carro->dataCompra = $dados['dataCompra'];
            $carro->marca = $dados['marca'];
            $carro->modelo = $dados['modelo'];
            $carro->tipo = $dados['tipo'];
            $carro->cor = $dados['cor'];
            $carro->anoModelo = $dados['anoModelo'];
            $carro->anoFabricacao = $dados['anoFabricacao'];
            $listadeCarros[] = $carro;
        }

        return $listadeCarros;
    }



    public function listar()
    {

        $sql = "select * from carros";
        $q = $this->conexao->prepare($sql);
        $q->execute();
        return $this->mapear($q);
    }
    public function listarCodigo($codigo, $limit = 1000)
    {

        $sql = "select * from carros where codigo like :codigo";
        $q = $this->conexao->prepare($sql);
        $codigo = "%" . $codigo . "%";
        $q->bindParam(":codigo", $codigo);
        $q->execute();
        return $this->mapear($q);
    }

    public function listarPlaca($codigo)
    {

        $sql = "select * from carros where placa like :codigo";
        $q = $this->conexao->prepare($sql);
        $codigo = "%" . $codigo . "%";
        $q->bindParam(":codigo", $codigo);
        $q->execute();
        return $this->mapear($q);
    }
    public function listarRenavam($codigo)
    {

        $sql = "select * from carros where renavam like :codigo";
        $q = $this->conexao->prepare($sql);
        $codigo = "%" . $codigo . "%";
        $q->bindParam(":codigo", $codigo);
        $q->execute();
        return $this->mapear($q);
    }
    public function listarDataCompra($codigo)
    {

        $sql = "select * from carros where dataCompra like :codigo";
        $q = $this->conexao->prepare($sql);
        $codigo = "%" . $codigo . "%";
        $q->bindParam(":codigo", $codigo);
        $q->execute();
        return $this->mapear($q);
    }
    public function listarMarca($codigo)
    {

        $sql = "select * from carros where marca like :codigo";
        $q = $this->conexao->prepare($sql);
        $codigo = "%" . $codigo . "%";
        $q->bindParam(":codigo", $codigo);
        $q->execute();
        return $this->mapear($q);
    }
    public function listarModelo($codigo)
    {

        $sql = "select * from carros where modelo like :codigo";
        $q = $this->conexao->prepare($sql);
        $codigo = "%" . $codigo . "%";
        $q->bindParam(":codigo", $codigo);
        $q->execute();
        return $this->mapear($q);
    }
    public function listarTipo($codigo)
    {

        $sql = "select * from carros where tipo like :codigo";
        $q = $this->conexao->prepare($sql);
        $codigo = "%" . $codigo . "%";
        $q->bindParam(":codigo", $codigo);
        $q->execute();
        return $this->mapear($q);
    }
    public function listarCor($codigo)
    {

        $sql = "select * from carros where cor like :codigo";
        $q = $this->conexao->prepare($sql);
        $codigo = "%" . $codigo . "%";
        $q->bindParam(":codigo", $codigo);
        $q->execute();
        return $this->mapear($q);
    }
    public function listarAnoModelo($codigo)
    {

        $sql = "select * from carros where anoModelo like :codigo";
        $q = $this->conexao->prepare($sql);
        $codigo = "%" . $codigo . "%";
        $q->bindParam(":codigo", $codigo);
        $q->execute();
        return $this->mapear($q);
    }
    public function listarAnoFabricacao($codigo)
    {

        $sql = "select * from carros where anoFabricacao like :codigo";
        $q = $this->conexao->prepare($sql);
        $codigo = "%" . $codigo . "%";
        $q->bindParam(":codigo", $codigo);
        $q->execute();
        return $this->mapear($q);
    }



    public function inserir($carro)
    {
        $sql = 'insert into carros(placa, renavam, dataCompra, marca, modelo, tipo, cor, anoModelo, anoFabricacao)
        values(:placa, :renavam, :dataCompra, :marca, :modelo, :tipo, :cor, :anoModelo, :anoFabricacao )';

        $q = $this->conexao->prepare($sql);
        $q->bindParam(':placa', $carro->placa);
        $q->bindParam(':renavam', $carro->renavam);
        $q->bindParam(':dataCompra', $carro->dataCompra);
        $q->bindParam(':marca', $carro->marca);
        $q->bindParam(':modelo', $carro->modelo);
        $q->bindParam(':tipo', $carro->tipo);
        $q->bindParam(':cor', $carro->cor);
        $q->bindParam(':anoModelo', $carro->anoModelo);
        $q->bindParam(':anoFabricacao', $carro->anoFabricacao);

        $q->execute();
    }

    public function eliminar($codigo)
    {

        $sql = "delete from carros where codigo = :codigo";
        $q = $this->conexao->prepare($sql);
        $q->bindParam(':codigo', $codigo);
        $q->execute();
    }

    public function atualizar($carro)
    {
        echo "Email enviado com Sucesso!";

        $sql = "update carros set placa = :placa, renavam = :renavam, dataCompra = :dataCompra, marca = :marca, modelo = :modelo, tipo = :tipo, cor = :cor,
        anoModelo = :anoModelo, anoFabricacao = :anoFabricacao where codigo = :codigo";

        $q = $this->conexao->prepare($sql);
        $q->bindParam(":codigo", $carro->codigo);
        $q->bindParam(':placa', $carro->placa);
        $q->bindParam(':renavam', $carro->renavam);
        $q->bindParam(':dataCompra', $carro->dataCompra);
        $q->bindParam(':marca', $carro->marca);
        $q->bindParam(':modelo', $carro->modelo);
        $q->bindParam(':tipo', $carro->tipo);
        $q->bindParam(':cor', $carro->cor);
        $q->bindParam(':anoModelo', $carro->anoModelo);
        $q->bindParam(':anoFabricacao', $carro->anoFabricacao);
        $q->execute();
    }




    public function getCarro($codigo)
    {

        $carro = new carroModel();
        $arrayCarro = $this->listarCodigo($codigo, 1);
        if (count($arrayCarro) > 0) {
            $carro = $arrayCarro[0];
        }
        return $carro;
    }
}
