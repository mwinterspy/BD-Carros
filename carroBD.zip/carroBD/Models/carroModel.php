<?php

class carroModel
{


    public $codigo;
    public $placa;
    public $renavam;
    public $dataCompra;
    public $marca;
    public $modelo;
    public $tipo;
    public $cor;
    public $anoModelo;
    public $anoFabricacao;


    public function formatData()
    {
        $dataFormat = strtotime($this->dataCompra);


        return date('d/m/Y', $dataFormat);
    }
}
