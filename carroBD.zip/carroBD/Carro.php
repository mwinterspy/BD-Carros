<?php

require 'Models/carroModel.php';
require 'conexao.php';


class Carro
{

    public $conexao;
    public function __construct()
    {
        $conec = new Conexao();
        $this->conexao = $conec->getConexao();
    }


    private function mapear($q)
    {
        $listadeCarros = [];
        foreach ($q as $dados) {
            $carro = new carroModel();
            $carro->codigo = $dados['codigo'];
            $carro->placa = $dados['placa'];
            $carro->renavam = $dados['renavam'];
            $carro->dataCompra = $dados['dataCompra'];
            $carro->marca = $dados['marca'];
            $carro->modelo = $dados['modelo'];
            $carro->tipo = $dados['tipo'];
            $carro->cor = $dados['cor'];
            $carro->anoModelo = $dados['anoModelo'];
            $carro->anoFabricacao = $dados['anoFabricacao'];
            $listadeCarros[] = $carro;
        }

        return $listadeCarros;
    }



    public function listar(){

        $sql = "select * from carros limit 10";
        $q = $this->conexao->prepare($sql);
        $q->execute();
        return $this->mapear($q);

    }

    public function inserir($carro){
        $sql = 'insert into carros(placa, renavam, dataCompra, marca, modelo, tipo, cor, anoModelo, anoFabricacao)
        values(:placa, :renavam, :dataCompra, :marca, :modelo, :tipo, :cor, :anoModelo, :anoFabricacao )';

        $q = $this->conexao->prepare($sql);
        $q->bindParam(':placa', $carro->placa);
        $q->bindParam(':renavam', $carro->renavam);
        $q->bindParam(':dataCompra', $carro->dataCompra);
        $q->bindParam(':marca', $carro->marca);
        $q->bindParam(':modelo', $carro->modelo);
        $q->bindParam(':tipo', $carro->tipo);
        $q->bindParam(':cor', $carro->cor);
        $q->bindParam(':anoModelo', $carro->anoModelo);
        $q->bindParam(':anoFabricacao', $carro->anoFabricacao);

        $q->execute();

    }
}
