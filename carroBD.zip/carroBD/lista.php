<?php


require 'Carro.php';
$c = new Carro();

$carros = $c->listar();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista Veículos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="style.css">
</head>
<header>
    <div class="container" style="margin-bottom: 150px">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark navbar fixed-top">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php"><i class="fa-solid fa-car-side"></i> Home</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Lista de Carros
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="lista.php">Exibir lista</a></li>
                                <li><a class="dropdown-item" href="cadastrar.php">Cadastrar novo veículo</a></li>
                            </ul>
                        </li>
                    </ul>
                    </form>
                </div>
            </div>

        </nav>
    </div>

</header>

<body>
    <div class="input-group" style="width: 500px;">
        <button class="btn btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">Dropdown</button>
        <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">Código</a></li>
            <li><a class="dropdown-item" href="#">Placa</a></li>
            <li><a class="dropdown-item" href="#">Renavam</a></li>
            <li><a class="dropdown-item" href="#">Data compra</a></li>
            <li><a class="dropdown-item" href="#">Something else here</a></li>
            <li><a class="dropdown-item" href="#">Something else here</a></li>
            <li><a class="dropdown-item" href="#">Something else here</a></li>
            <li><a class="dropdown-item" href="#">Something else here</a></li>
        </ul>
        <input type="text" class="form-control">
        <button class="btn btn-outline-secondary" type="button" id="button-addon2"><i class="fa-solid fa-magnifying-glass"></i></button>
    </div>
    <div style="margin: 50px">
        <table class="table table-striped table-bordered">
            <thead class="table-dark">
                <tr>
                    <th scope="col">Código</th>
                    <th scope="col">Placa</th>
                    <th scope="col">Renavam</th>
                    <th scope="col">Data da Compra</th>
                    <th scope="col">Marca</th>
                    <th scope="col">Modelo</th>
                    <th scope="col">Tipo</th>
                    <th scope="col">Cor</th>
                    <th scope="col">Ano Modelo</th>
                    <th scope="col">Ano Fabricação</th>
                </tr>
            </thead>

            <?php

            foreach ($carros as $carro) {

            ?>
                <tbody>
                    <tr>
                        <td><?php echo $carro->codigo ?></td>
                        <td><?php echo $carro->placa ?></td>
                        <td><?php echo $carro->renavam ?></td>
                        <td><?php echo $carro->dataCompra ?></td>
                        <td><?php echo $carro->marca ?></td>
                        <td><?php echo $carro->modelo ?></td>
                        <td><?php echo $carro->tipo ?></td>
                        <td><?php echo $carro->cor ?></td>
                        <td><?php echo $carro->anoModelo ?></td>
                        <td><?php echo $carro->anoFabricacao ?></td>
                    </tr>
                </tbody>




            <?php
            }
            ?>



</body>

</html>