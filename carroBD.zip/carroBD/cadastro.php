<?php

   require 'Carro.php';

    $c = new Carro();
    $carro = new carroModel();

    $carro->placa = $_POST['placa'];
    $carro->renavam = $_POST['renavam'];
    $carro->dataCompra = $_POST['dataCompra'];
    $carro->marca = $_POST['marca'];
    $carro->modelo = $_POST['modelo'];
    $carro->tipo = $_POST['tipo'];
    $carro->cor = $_POST['cor'];
    $carro->anoModelo = $_POST['anoModelo'];
    $carro->anoFabricacao = $_POST['anoFabricacao'];

    $c->inserir($carro);
    header('location: lista.php');


?>