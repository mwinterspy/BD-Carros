<?php
    require 'Carro.php';
    $carro = new carroModel();

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="style.css">
</head>
<header>
    <div class="container" style="margin-bottom: 150px">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark navbar fixed-top">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php"><i class="fa-solid fa-car-side"></i> Home</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Lista de Carros
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="lista.php">Exibir lista</a></li>
                                <li><a class="dropdown-item" href="cadastrar.php">Cadastrar novo veículo</a></li>
                            </ul>
                        </li>
                    </ul>
                    </form>
                </div>
            </div>

        </nav>
    </div>
</header>

<body>
    <div class="container d-flex align-items-center justify-content-center" id="formulario">
        <form action="cadastro.php" method="POST">
            <div style="margin-right: 10px; float: left;">
                <div class="mb-3">
                    <label class="form-label" style="margin-left: 1px;">Código</label>
                    <input value=""type="text" name="codigo" class="form-control" id="codigo"style="width: 350px;" readonly>
                </div>
                <div class="mb-3">
                    <label class="form-label" style="margin-left: 1px;">Placa</label>
                    <input type="text" name="placa" class="form-control" id="placa"style="width: 350px;">
                </div>
                <div class="mb-3">
                    <label class="form-label" style="margin-left: 1px;">Renavam</label>
                    <input type="text" name="renavam" class="form-control" id="renavam"style="width: 350px;">
                </div>
                <div class="mb-3">
                    <label class="form-label" style="margin-left: 1px;">Data compra</label>
                    <input type="date" name="dataCompra" class="form-control" id="dataCompra"style="width: 350px;">
                </div>
                <div class="mb-3">
                    <label class="form-label" style="margin-left: 1px;">Marca</label>
                    <input type="text" name="marca" class="form-control" id="marca"style="width: 350px;">
                </div>
            </div>
            <div style="margin-left:10px; float:right;">
                <div class="mb-3">
                    <label class="form-label" style="margin-left: 1px;">Modelo</label>
                    <input type="text" name="modelo" class="form-control" id="modelo"style="width: 350px;">
                </div>
                <div class="mb-3">
                    <label class="form-label" style="margin-left: 1px;">Cor</label>
                    <input type="text" name="cor" class="form-control" id="cor" style="width: 350px;">
                </div>
                <div class="mb-3">
                    <label class="form-label" style="margin-left: 1px;">Tipo</label>
                    <select class="custom-select form-control" id="tipo" name="tipo"  style="width: 350px; height: 40px;">
                        <option selected>Selecione</option>
                        <option value="Sedan">Sedan</option>
                        <option value="Hatch">Hatch</option>
                        <option value="Picape">Picape</option>
                        <option value="Esportivo">Esportivo</option>
                        <option value="SUV">SUV</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label" style="margin-left: 1px;">Ano modelo</label>
                    <input type="text" name="anoModelo" class="form-control" id="anoModelo"style="width: 350px;">
                </div>
                <div class="mb-3">
                    <label class="form-label" style="margin-left: 1px;width: 350px;">Ano Fabricacao</label>
                    <input type="text" name="anoFabricacao" class="form-control" id="anoFabricacao" style="width: 350px;">
                </div>
            </div>

            <div style="float:bottom">
                <button type="submit" class="btn btn-primary">Cadastrar</a></button>
            </div>

        </form>
    </div>

</body>

</html>